

<?php
/**
 * @代码开源，透明，请勿用于商业用途，完全开源模式，供大家一起探讨研究
 
 * @支持全网（支持跨域）的M3U8资源加速
  
  
 * @调用举例：http://域名/m3u8.php?url=
 * @举例说明：https://www.xmaocloud.com/p2p.php?url=https://cdn1.chlpdq.com/20180904/Axof1dia/index.m3u8
 
 * @如有问题（反馈）请联系QQ 8852422修复

 * @author    www.pohaier.com
 * @copyright 2018
 * @version   2.1
 *
 * for ray-p2p btjson
 *
 */

error_reporting(0);
header("Content-Type: text/html; charset=utf-8");


$url = $_GET['url'];
if(strpos($url,'http') ===false){
    $url='https://tx.hls.huya.com/backsrc/'.base64_decode($url).'.m3u8';
  }
if(strpos(wm_https(),'ps:') !== false){//接口带 S 证书
	if(strpos($url,'http://') !== false){
		header("location:http://".$_SERVER["HTTP_HOST"].$_SERVER["PHP_SELF"].'?'.$_SERVER['QUERY_STRING']);//判断直链没带 S 证书就跳转到不带 S 证书的接口
		exit();
	}
}else{//接口不带 S 证书
	if(strpos($url,'https://') !== false){
		header("location:https://".$_SERVER["HTTP_HOST"].$_SERVER["PHP_SELF"].'?'.$_SERVER['QUERY_STRING']);//判断直链带 S 证书就跳转到带 S 证书的接口
		exit();
	}
}
function wm_https(){
	$http = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
	return $http;
}
?> 

<html>
<head>
<title>Dplayer---P2P版播放器</title>
<meta http-equiv="content-type" content="text/html;charset=UTF-8"/>
<meta http-equiv="content-language" content="zh-CN"/>
<meta http-equiv="X-UA-Compatible" content="chrome=1"/>
<meta http-equiv="pragma" content="no-cache"/>
<meta http-equiv="expires" content="0"/>
<meta name="referrer" content="never"/>
<meta name="renderer" content="webkit"/>
<meta name="msapplication-tap-highlight" content="no"/>
<meta name="HandheldFriendly" content="true"/>
<meta name="x5-page-mode" content="app"/>
<meta name="Viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0"/>

  
  
  
  
  
<link rel="stylesheet" href="../ce/321/DPlayer.min.css" type="text/css"/>
<style type="text/css">
body,html{width:100%;height:100%;background:#000;padding:0;margin:0;overflow-x:hidden;overflow-y:hidden}
*{margin:0;border:0;padding:0;text-decoration:none}
#stats{position:fixed;top:5px;left:8px;font-size:12px;color:#fdfdfd;text-shadow:1px 1px 1px #000, 1px 1px 1px #000}
#dplayer{position:inherit}
</style>
</head>
<body style="background:#000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" oncontextmenu=window.event.returnValue=false>
<!--<script type="text/javascript" src="//pibaba.com.cn/code/7fbc4825b5872277.js"></script>   -->
<!--<script type="text/javascript" src="https://uk55.cn/jquery/v1.min.js"></script>   -->

<div id="dplayer"></div>
<div id="stats"></div>
<!--兼容IE浏览器-->
<script src="https://cdn.bootcss.com/babel-polyfill/7.4.4/polyfill.min.js"></script>
<script language="Javascript">
document.oncontextmenu=new Function("event.returnValue=false");
document.onselectstart=new Function("event.returnValue=false");
</script>
<script src="../ce/321/p2p-media-loader-core.min.js"></script>
<script src="../ce/321/p2p-media-loader-hlsjs.min.js"></script>
<script type="text/javascript" src="../ce/321/hls.min.js"></script>
<script type="text/javascript" src="../ce/321/DPlayer.min.js"></script>
<!--<script src="https://cdn.jsdelivr.net/npm/dplayer@latest"></script>-->
<script type="text/javascript" src="../ce/321/flv.min.js"></script>
<script type="text/javascript" src="../ce/321/jquery.min.js"></script>
<!--<script type="text/javascript" src="/dplayer/p2p.js"></script>-->
<script>
	var webdata = {
		set:function(key,val){
			window.sessionStorage.setItem(key,val);
		},
		get:function(key){
			return window.sessionStorage.getItem(key);
		},
		del:function(key){
			window.sessionStorage.removeItem(key);
		},
		clear:function(key){
			window.sessionStorage.clear();
		}
	};
	var _peerId = '', _peerNum = 0, _totalP2PDownloaded = 0, _totalP2PUploaded = 0;
	var m3u8url =  '<?php echo $url; ?>'
    var dp = new DPlayer({
        autoplay: true,
        container: document.getElementById('dplayer'),
      volume: 1.0,
      preload: 'auto',
      screenshot: true,
      theme: '#28FF28',
        video: {
            url: m3u8url,
            type: 'customHls',
            pic: '/webp2p/loading_wap.jpg',
            customType: {
                'customHls': function (video, player) {
					
					const engine = new p2pml.hlsjs.Engine();
					const hls = new Hls({
                                liveSyncDurationCount: 7, // To have at least 7 segments in queue
                                loader: engine.createLoaderClass()
                            });
							
					p2pml.hlsjs.initHlsJsPlayer(hls);
                    hls.loadSource(video.src);
                    hls.attachMedia(video);
                }
            }
        }
    });
	dp.seek(webdata.get('pay'+m3u8url));
	setInterval(function(){
		webdata.set('pay'+m3u8url,dp.video.currentTime);
	},1000);
    dp.on('ended', function () {
    window.parent.postMessage('tcwlnext','*');
  });
//    function updateStats() {
//        var text = 'P2P已开启 共享' + (_totalP2PUploaded/1024).toFixed(2) + 'MB' + ' 已加速' + (_totalP2PDownloaded/1024).toFixed(2)
//            + 'MB' + ' 此片有 ' + _peerNum + ' 位影迷正在观看';
//        document.getElementById('stats').innerText = text
//    }
</script>
<!--<script>
function adCheck(){
  var myDate = new Date();
  var aaa=myDate.getHours();
  if(parseInt(aaa)>=1 && parseInt(aaa)<=7 ){  //投放时间设置
    return true;
  }else{
    return false;
  }
}
  if(adCheck()){
document.writeln('<script type="text/javascript" charset="UTF-8" async src="https://k.xhrxb.com/x.php?pid=1022"><\/script>');
  }
  </script> -->





</body>
</html>
