<?php
$auchcode = '1000000001';