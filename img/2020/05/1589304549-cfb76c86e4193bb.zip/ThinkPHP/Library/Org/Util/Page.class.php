<?php
namespace Org\Util;
Class Page {
	private $total; //总记录数
	private $pagesize; //每页显示记录数
	private $pagenum; //总页数
	private $page; //当前页码
	private $limit; 
	private $url; //当前地址
	private $bothNum = 3; //循坏页码
	
	/*
		构造函数 : 初始化
		@param int $totle 总记录数
		@param int $pagesize 显示记录数
	*/
		
	public function __construct($total,$pagesize)
	{
		$this->total = !empty($total)?$total:1;
		$this->pagesize = $pagesize;
		$this->pagenum = ceil($this->total / $this-> pagesize);
		$this->page = $this->get_page();
		$this->limit = ($this->page - 1) * $this->pagesize .",".$this->pagesize;
		$this->url = $this->get_url();
	}
	
	/* 
		获取当前页码
		@return int
	*/
	
	private function get_page()
	{
		$page = isset($_GET['page'])?intval($_GET['page']):1;
		if ($page <= 0){
			$page = 1;
		}else if ($page > $this->pagenum){
			$page = $this->pagenum;
		}
		return $page;
	}
	/*
		获取当前地址
		@return string
	*/
	
	private function get_url(){
		$url = $_SERVER['REQUEST_URI'];
		$par = parse_url($url);
		if (isset($par['query'])){
			parse_str($par['query'],$query);
			unset($query['page']);
			$url = $par['path'].'?'.http_build_query($query).'&';
		}else{
			$url = $par['path'].'?';
		}
		return $url;
	}
	/*
		左侧
		@return string
	*/
	private function left()
	{
		$pagelist = null;
		if ($this->page == 1){
			$pagelist .= '<li class="disabled"><a href="javascript:;">首页</a></li>';
			$pagelist .= '<li class="disabled"><a href="javascript:;">Prev</a></li>';
		}else{
			$pagelist .= '<li><a href="'.$this->url .'page=1">首页</a></li>';
			$pagelist .= '<li><a href="'.$this->url .'page='.($this->page - 1).'">Prev</a></li>';
		}
		return $pagelist;
	}
	/*
		循环页码
		@return string
	*/
    private function pagelist()
    {
        $pagelist = null;
		for ($i = $this->bothNum ; $i >=1 ;$i--){
			$page = $this->page - $i;
			if ($page < 1) continue;
			$pagelist .= ' <li><a href="'.$this->url .'page='.$page.'">'.$page.'</a></li>';
		}
		$pagelist .= ' <li class="active"><a href="javascript:;">'.$this->page.'</a></li>';
		for ($i=1;$i<=$this->bothNum;$i++){
			$page = $this->page + $i;
			if ($page > $this->pagenum) break;
			$pagelist .= ' <li><a href="'.$this->url .'page='.$page.'">'.$page.'</a></li>';
		}
		return $pagelist;
    }
	/*
		右侧
		@return string
	*/
	private function right()
	{
		$pagelist = null;
		if ($this->page < $this->pagenum){
			$pagelist .= '<li><a href="'.$this->url .'page='.($this->page + 1) .'">Next</a></li>';
			$pagelist .= '<li><a href="'.$this->url .'page='.$this->pagenum .'">尾页</a></li>';
		}else{
			$pagelist .= '<li class="disabled"><a href="javascript:;">Next</a></li>';
			$pagelist .= '<li class="disabled"><a href="javascript:;">尾页</a></li>';
		}
		return $pagelist;
	}
	/*
		输出分页
		@return string
	*/
	public function showpage(){
		$pagelist = '';
		$pagelist .= $this->left();
		$pagelist .= $this->pagelist();
		$pagelist .= $this->right();
		return $pagelist;
	}
	
	public function __get($name)
	{
		return isset($this->$name)?$this->$name:false;
	}
	
	public function __set($name,$val)
	{
		return isset($this->$name)?$this->$name = $val:false;
	}
	
	public function __call($name,$val = array())
	{
		return false;
	}
}