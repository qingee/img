DROP TABLE IF EXISTS `auth_site`;
CREATE TABLE `auth_site`(
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uin` varchar(20) DEFAULT NULL,
  `url` varchar(150) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `authcode` varchar(100) DEFAULT NULL,
  `sign` varchar(20) DEFAULT NULL,
  `active` int(1) DEFAULT '1',
  PRIMARY KEY (`id`)
)ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `auth_user`;
CREATE TABLE `auth_user`(
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(100) NOT NULL UNIQUE,
  `pass` VARCHAR(100) NOT NULL,
  `uin` VARCHAR(20) NOT NULL,
  `regtime` datetime DEFAULT NULL,
  `lasttime` datetime DEFAULT NULL,
  `userip` VARCHAR(20) DEFAULT NULL,
  `per_sq` int(1) DEFAULT '1',
  `active` int(1) DEFAULT '1',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `auth_admin`;
CREATE TABLE `auth_admin`(
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `user` VARCHAR(100) NOT NULL UNIQUE,
  `pass` VARCHAR(100) NOT NULL,
  `uin`  VARCHAR(20) NOT NULL,
  `regtime` datetime DEFAULT NULL,
  `lasttime` datetime DEFAULT null,
  `userip` VARCHAR(20) DEFAULT null,
  `per_sq` int(1) DEFAULT '1',
  `per_sr` int(1) DEFAULT '0',
  `active` int(1) DEFAULT '1',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
INSERT INTO `auth_admin`(`user`,`pass`,`uin`,`regtime`,`per_sq`,`per_sr`,`active`) VALUES ('admin','123456','123456','2017-01-01',1,1,1);

  


