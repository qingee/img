<?php
/*
贝塔先生<1043897710@qq.com>
原微光之前qq号出售了 emmm
微光自助授权系统
qq群:759708960
*/
return array(
	'DB_TYPE'               =>  'mysqli',     // 数据库类型
    'DB_HOST'               =>  'localhost', // 服务器地址
    'DB_NAME'               =>  '数据库名',          // 数据库名
    'DB_USER'               =>  '用户名',      // 用户名
    'DB_PWD'                =>  '密码',          // 密码
    'DB_PORT'               =>  '3306',        // 端口
    'DB_PREFIX'             =>  'auth_',    // 数据库表前缀
	'URL_HTML_SUFFIX'       =>  'beita',  // URL伪静态后缀设置
);