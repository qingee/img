<?php
/*
贝塔先生<1043897710@qq.com>
原微光之前qq号出售了 emmm
微光自助授权系统
qq群:759708960
*/
namespace Home\Model;
Class ToolsModel{
	public function create($type,$authcode,$sign=''){
		import('Org.Util.PclZip');
		$path = $type == 'install'?INSTALL:UPDATE;
		$file_path = ROOT.PACKAGE_DIR.'/'.$path;
		$file_str = file_get_contents(ROOT.PACKAGE_DIR.'/authcode.php');
		$file_str = str_replace('1000000001',$authcode,$file_str);
		@file_put_contents(ROOT.PACKAGE_DIR.'/'.$path.'/'.authcodeaddr.'/authcode.php',$file_str);
		$file_name = $type == 'install'?INAME:UNAME;
		$file = ROOT.CACHE_DIR."/".substr($authcode,0,14).bin2hex($type).".zip";
		if (file_exists($file))unlink($file);
		$zip = new \PclZip($file);
		$v_list = $zip->create($file_path,PCLZIP_OPT_REMOVE_PATH,$file_path);
		$file_size=filesize("$file");
		header("Content-Description: File Transfer");
		header("Content-Type:application/force-download");
		header("Content-Length: {$file_size}");
		header("Content-Disposition:attachment; filename={$file_name}");
		readfile("$file");
	}
	public function export($file_name,$file_data){
		$filesize = strlen($file_data);
		header("Content-Description: File Transfer");
		header("Content-Type: application/force-download");
		header("Content-Length: {$filesize}");
		header("Content-Disposition: attachment; filename={$file_name}");
		exit($file_data);
	}
}