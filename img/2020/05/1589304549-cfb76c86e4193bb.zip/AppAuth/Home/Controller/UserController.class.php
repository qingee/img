<?php
/*
贝塔先生<1043897710@qq.com>
原微光之前qq号出售了 emmm
微光自助授权系统
qq群:759708960
*/
namespace Home\Controller;
use Think\Controller;
use \Org\Util\Page;
Class UserController extends Controller{
    protected $user;
	public function _empty()
	{
		$this->display('Error/index');
	}
    public function index()
    {
		$authcount = count(M('site')->field('id')->select());
		$usercount = count(M('user')->field('uid')->select());
		$this->assign('authcount',$authcount);
		$this->assign('usercount',$usercount);
        $this->assign('webTitle','平台首页');
        $this->display();
    }
    public function list()
    {
        $this->check_sq();
        if (I('param.do') == 'del' && $id = I('param.id/d')){
            if (!M('site')->where("id={$id}")->delete()){
                get_exit('删除失败:不存在或已删除',U('list'));
            }
            get_exit('删除成功',U('list'));
        }
        if (I('param.kw') != ''){
            $kw = base64_decode(I('param.kw'));
            if (I('param.type') == 1){
                $where = I('param.method') == 1 ? "uin like '%{$kw}%'":"uin='{$kw}'";
            }else if (I('param.type') == 2){
                $where = I('param.method') == 1 ? "url like '%{$kw}%'":"url='{$kw}'";
            }elseif (I('param.type') == 3){
                $where = I('param.method') == 1 ? "authcode like '%{$kw}%'":"authcode='{$kw}'";
            }elseif (I('param.type') == 4){
                $where = I('param.sign') == 1 ? "sign like '%{$kw}%'":"sign='{$kw}'";
            }else{
                $where = I('param.method') == 1 ? "url like '%{$kw}%' or uin like '%{$kw}%'":"url='{$kw}' or uin='{$kw}'";
            }
        }else if ($qq = I('param.qq')){
            $where = "uin = '{$qq}'";
        }else{
            $where = 1;
        }
        $pagecount = count(M('site')->field('id')->where($where)->select());
        $pageobj = new Page($pagecount,25);
        $pagedata = M('site')->field('*')->where($where)->order('id DESC')->limit($pageobj->limit)->select();
        $this->assign('pagecount',$pagecount);
        $this->assign('pageobj',$pageobj);
        $this->assign('pagedata',$pagedata);
        $this->assign('webTitle','授权列表');
        $this->display();
    }
    public function add()
    {
        $this->check_sq();
        if (IS_POST){
            $uin = I('post.uin','','daddslashes');
            $url = I('post.url','','daddslashes');
            if ($uin == '' || $url == ''){
                get_exit('各项都不能为空',2);
            }
            if (M('site')->where("uin='{$uin}'")->find()){
                get_exit('授权平台已有此QQ授权，请使用添加站点功能',U('addsite'));
            }
            $sign = M('site')->field('sign')->order('sign DESC')->find();
            $sign = $sign['sign'] + 1;
            $authcode = MD5(base64_encode($uin).time().uniqid().'^%@#');
            $urls = explode(',',$url);
            foreach ($urls as $k=>$v){
                M('site')->add(array('uin'=>$uin,'url'=>$v,'date'=>date('Y-m-d h:i:s'),'sign'=>$sign,'authcode'=>$authcode,'active'=>1));
            }
            get_exit('添加成功',U('downfile',array('qq'=>$uin)));
        }
        $this->assign('webTitle','添加授权');
        $this->display();
    }
    public function addsite()
    {
        $this->check_sq();
        if(IS_POST){
            $uin = I('post.uin','','daddslashes');
            $url = I('post.url','','daddslashes');
            if (!$row = M('site')->field('*')->where("uin='{$uin}'")->find()){
                get_exit('授权平台不存在该QQ，请使用添加授权功能',U('add'));
            }
            if ($row['active'] == 0){
                get_exit('此QQ的授权已被封禁！');
            }
            $urls = explode(',',$url);
            foreach ($urls as $v){
                if (M('site')->where("url='{$v}'")->find()) continue;
                M('site')->add(array('uin'=>$uin,'url'=>$v,'date'=>date('Y-m-d h:i:s'),'authcode'=>$row['authcode'],'sign'=>$row['sign'],'active'=>1));
            }
            get_exit('添加成功',U('downfile',array('qq'=>$uin)));
        }
        $this->assign('webTitle','添加站点');
        $this->display();
    }
    public function edit($id)
    {
        $id = intval($id);
        if (!$row = M('site')->where("id={$id}")->find()){
            get_exit('授权不存在',U('list'));
        }
        if (IS_POST){
            if (strlen(I('post.authcode')) != 32){
                get_exit('授权码格式不正确');
            }
            $data = array();
            $data['uin'] = I('post.uin','','daddslashes');
            $data['url'] = I('post.url','','daddslashes');
            $data['authcode'] = I('post.authcode','','daddslashes');
            $data['sign'] = I('post.sign/d');
            $data['active'] = I('post.active/d');
            M('site')->where("id={$id}")->save($data);
            get_exit('修改成功');
        }
        $this->assign('row',$row);
        $this->assign('webTitle','编辑授权');
        $this->display();
    }
    public function search()
    {
        $this->check_sq();
        if (IS_POST){
            $data = array();
            $data['type'] = I('post.type/d');
            $data['kw'] = base64_encode(I('post.kw','','daddslashes'));
            $data['method'] = I('post.method/d');
            $this->redirect('list',$data);
        }
        $this->assign('webTitle','搜索授权');
        $this->display();
    }
    public function downfile()
    {
        $this->check_sq();
        $qq = I('param.qq');
        if (!empty($qq)){
            $row = M('site')->where("uin='{$qq}'")->find();
            if ($row == '')get_exit('授权平台不存在该QQ！',U('downfile'));
            $active = M('site')->where("uin='{$qq}' and active=0")->find();
            if ($active != ''){
                get_exit('此QQ的授权已被封禁',U('downfile'));
            }
            $this->assign('row',$row);
            $this->assign('webTitle','源码下载');
            $this->display('download');
        }else{
            $this->assign('webTitle','下载管理');
            $this->display();
        }
    }
    public function download()
    {
        $this->check_sq();
        $type = I('param.type','','daddslashes');
        $authcode = I('param.authcode','','daddslashes');
        $sign = I('param.sign','','daddslashes');
        if (empty($authcode) || empty($sign))get_exit('授权码或特征码不能为空',U('downfile'));
        if ($type == 'install')
            D('Tools')->create('install',$authcode,$sign);
        elseif($type == 'update')
            D('Tools')->create('update',$authcode,$sign);
        else
            get_exit('类型错误');
    }
    private function check_sq()
    {
        if ($this->user['per_sq'] == 0){
            get_exit('您的账号没有权限使用此功能！',U('index'));
        }
    }
    public function logout(){
        cookie('user_auth',null);
        get_exit('退出登陆成功',U('login'));
    }
    public function login()
    {
        if (IS_POST){
            $user = I('post.user','','daddslashes');
            $pass = I('post.pass','','daddslashes');
			$udata = M('user')->field('*')->where("user='{$user}'")->find();
			if (!$udata){
				get_exit('用户不存在！');
			}
			if ($pass != $udata['pass']){
				get_exit('密码不正确！');
			}
			if ($udata['active'] == 0){
				get_exit('帐号已冻结！');
			}
			if ($udata){
                M('user')->where("user='{$user}'")->setField('lasttime',date('Y-m-d h:i:s'));
                M('user')->where("user='{$user}'")->setField('userip',real_ip());
				$sign = encrypt("{$user}\t".MD5($user,$pass.'#^&*(%^%4413'),'ENCODE');
				cookie('user_auth',$sign,time()+604800);
				get_exit('登录成功！',U('index'));
			}
        }
        $this->display();
    }
    public function __construct()
    {
        parent::__construct();
        if(ACTION_NAME != 'login'){
			$udata = decrypt(cookie('user_auth'),'ENCODE');
			list($username,$sign) = explode("\t",$udata);
			$user = M('user')->field('*')->where("user='{$username}'")->find();
			$sign2 = MD5($user['user'],$user['pass'].'#^&*(%^%4413');
			if ($sign == $sign2){
				$this->user= $user;
			}else{
				get_exit(0,U('login'));
			}
        }
    }
}