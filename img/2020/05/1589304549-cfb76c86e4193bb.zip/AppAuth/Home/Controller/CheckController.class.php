<?php
/*
贝塔先生<1043897710@qq.com>
原微光之前qq号出售了 emmm
微光自助授权系统
qq群:759708960
*/
namespace Home\Controller;
use Think\Controller;
Class CheckController extends Controller{
	public function _empty()
	{
		$this->display('Error/index');
	}
    public function qq() // 验证QQ是否授权
    {
		$qq = I('param.qq','','daddslashes');
        if ($row = M('site')->where("uin='{$qq}' and active=1 and del=0")->find()) {
            die('1');
        }else{
            die('0');
        }
    }
    public function url()
    {
        $url = I('param.url','','daddslashes');
        if ($row = M('site')->where("uin='{$url}' and active=1 and del=0")->find()) {
            die('1');
        }else{
            die('0');
        }
    }
	public function updateapp() //更新
	{
		
	}
}