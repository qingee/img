<?php
/*
贝塔先生<1043897710@qq.com>
原微光之前qq号出售了 emmm
微光自助授权系统
qq群:759708960
*/
namespace Home\Controller;
use Think\Controller;
Class GetController extends Controller{
	public function _empty()
	{
		$this->display('Error/index');
	}
    Public function index()
    {
        $this->display();
    }
    public function qqlogin()
    {
        $do = I('param.do');
        if ($do == 'getqrpic'){
            D('Qqlogin')->getqrpic();
        }
        if ($do == 'qqlogin'){
            D('Qqlogin')->qqlogin();
        }
    }
    public function download()
    {
        $get_token = !empty(session('get_token'))?session('get_token'):exit;
        $uin = I('param.qq','','daddslashes');
        if (!$get_token || !$uin) {
            exit();
        }
        $tokenid = base64_encode(md5($uin.md5($uin.'*$$*').'23132'.md5(date("Y-m-d-H"))));
        if ($get_token != $tokenid){
            exit("<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
                <script language='javascript'>alert('验证信息已过期，请返回重新扫码验证。');history.go(-1);</script>");
        }
        $row = M('site')->where("uin='{$uin}'")->find();
        if (!$row['authcode'] || !$row['sign'] ){
            exit();
        }
        if (I('param.do') == 'installer'){
            D('Tools')->create('install',$row['authcode'],$row['sign']);
        }else if (I('param.do') == 'updater'){
            D('Tools')->create('update',$row['authcode'],$row['sign']);
        }
    }
}