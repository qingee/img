<?php
/*
贝塔先生<1043897710@qq.com>
原微光之前qq号出售了 emmm
微光自助授权系统
qq群:759708960
*/
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
	public function _empty()
	{
		$this->display('Error/index');
	}
    public function index(){
		if (I('post.url','','daddslashes') && IS_POST) {
			$p_url = base64_encode(I('post.url', '', 'daddslashes'));
			$this->redirect('index', array('url' => $p_url));
		}
		if (I('param.url','','daddslashes') && IS_GET){
			$g_url = base64_decode(I('param.url', '', 'daddslashes'));
			$res = M('site')->field('*')->where("url='{$g_url}'")->find();
			if ($res && $res['active'] == 1){
				$this->assign('res',true);
			}else{
				$this->assign('res',false);
			}
			$this->assign('url',$g_url);
		}
		$this->display();
	}

}