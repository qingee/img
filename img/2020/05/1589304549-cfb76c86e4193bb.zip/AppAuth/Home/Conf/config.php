<?php
return array(
/*
贝塔先生<1043897710@qq.com>
原微光之前qq号出售了 emmm
微光自助授权系统
qq群:759708960
*/
);